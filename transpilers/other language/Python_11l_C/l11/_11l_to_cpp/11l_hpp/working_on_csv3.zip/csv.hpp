﻿namespace csv
{
class Reader
{
	File file;
	Char delimiter;
	bool check_bom = true;
	Array<char> row_data;
	Array<Int> delim_positions;

	class Row
	{
		Reader *reader;

		class Column
		{
			Reader *reader;
			Int index;

		public:
			Column(Reader *reader, Int index) : reader(reader), index(index) {}
			operator Int  () const {return to_int_t<Int  >(reader->get_column_cstr(index));}
			operator Int64() const {return to_int_t<Int64>(reader->get_column_cstr(index));}
			operator double() const {return atof(reader->get_column_cstr(index));}
			operator String() const {return reader->get_column_string(index);}
		};

	public:
		Row(Reader *reader) : reader(reader) {}
		Column operator[](Int index) {return Column(reader, index);}
	};

	class Iterator
	{
		Reader *reader;

	public:
		Iterator(Reader *reader) : reader(reader) {}
		bool operator!=(Iterator i) const {
			assert(i.reader == nullptr);
			return reader != nullptr;
		}
		void operator++() {if (!reader->read_row()) reader = nullptr;}
		Row operator*() const {return Row(reader);}
	};

	bool read_row()
	{
	}

	const char *get_column_cstr(Int column_index)
	{
		if (column_index == delim_positions.len()) { // this is the last column
			if (row_data.last() != 0) // this is a hack (because there is no distinction if \0 character was added here already or it was present in csv file), which can be avoided only when to_int_t() will accept string length argument
				row_data.append(0);
			return &row_data[delim_positions.last()];
		}
		row_data[delim_positions[column_index]] = 0;
		return &row_data[column_index == 0 ? 0 : delim_positions[column_index - 1] + 1];
	}
	String get_column_string(Int column_index)
	{
		Int start = column_index == 0 ? 0 : delim_positions[column_index - 1] + 1,
		    end   = column_index == delim_positions.len() ? row_data.len() : delim_positions[column_index];
		return convert_utf8_string_to_String(&row_data[start], end - start);
	}

public:
	Reader(const String &file_name, const String &encoding = u"utf-8"_S, const String &delimiter = u","_S) : file(file_name), delimiter(delimiter)
	{
	}

	Iterator begin()
	{
		return Iterator(this);
	}

	Iterator end()
	{
		return Iterator(nullptr);
	}
};

Reader read(const String &file_name, const String &encoding = u"utf-8"_S, const String &delimiter = u","_S)
{
	return Reader(file_name, encoding, delimiter);
}
}
