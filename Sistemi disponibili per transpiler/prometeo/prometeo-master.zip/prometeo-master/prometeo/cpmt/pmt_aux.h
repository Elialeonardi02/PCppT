#ifndef PMT_AUX_H_
#define PMT_AUX_H_

#ifdef __cplusplus
extern "C" {
#endif

int align_char_to(int num, char **c_ptr);

#ifdef __cplusplus
}
#endif

#endif // PMT_AUX_H_
