#ifndef PROMETEO_HEAP_H_
#define PROMETEO_HEAP_H_

#ifdef __cplusplus
extern "C" {
#endif

extern void* ___c_pmt_8_heap;
extern void* ___c_pmt_64_heap;

#ifdef __cplusplus
}
#endif

#endif // PROMETEO_HEAP_H_
