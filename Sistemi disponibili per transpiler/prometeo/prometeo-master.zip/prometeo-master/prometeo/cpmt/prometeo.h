#ifndef PROMETEO_H_
#define PROMETEO_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "pmat_blasfeo_wrapper.h"
#include "pvec_blasfeo_wrapper.h"
#include "pmt_heap.h"

#ifdef __cplusplus
}
#endif

#endif // PROMETEO_H_
