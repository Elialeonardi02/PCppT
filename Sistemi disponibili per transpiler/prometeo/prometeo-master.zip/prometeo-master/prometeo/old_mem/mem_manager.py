import malloc_wrapper
class mem_manager:
    
    heap_db = {}
    use_prmt_heap = False


    
