from prometeo import *

def main() -> int:

    print('\nhello world!\n')

    return 0

