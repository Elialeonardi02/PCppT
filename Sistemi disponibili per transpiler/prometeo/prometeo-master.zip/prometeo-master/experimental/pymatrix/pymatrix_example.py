#! /usr/bin/python3.6
import pymatrix as p

A = p.Matrix(2,2)
B = p.Matrix(2,2)
C = A*B
print (A[1][1])
print (C)
