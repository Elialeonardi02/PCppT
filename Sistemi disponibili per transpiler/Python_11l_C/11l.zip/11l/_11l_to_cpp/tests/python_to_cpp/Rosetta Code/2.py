from typing import List

l : List[int] = None
l = [67]
l = None