﻿#include "C:\!!BITBUCKET\11l-lang\_11l_to_cpp\11l.hpp"

struct CodeBlock1
{
    CodeBlock1()
    {
        for (auto i : range_ee(0, 10))
            print(u"Hello World"_S[range_ee(0, i)]);
    }
} code_block_1;

int main()
{
}
