if True:
    print(x)
    x = 9