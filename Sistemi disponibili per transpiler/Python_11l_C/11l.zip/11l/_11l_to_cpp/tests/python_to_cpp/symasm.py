class Error:
    message: str
