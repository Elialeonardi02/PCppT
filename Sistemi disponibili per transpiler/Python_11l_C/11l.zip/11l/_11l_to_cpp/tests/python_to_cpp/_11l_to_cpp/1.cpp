﻿#include "C:\!!BITBUCKET\11l-lang\_11l_to_cpp\11l.hpp"

Array<String> empty_list_of_str;
Array<Set<String>> binary_operators = create_array({std::move(create_set(empty_list_of_str))});

int main()
{
}
