import prime

prime.testf()