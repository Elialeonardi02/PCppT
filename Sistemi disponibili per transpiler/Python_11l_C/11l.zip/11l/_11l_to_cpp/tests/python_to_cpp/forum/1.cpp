﻿#include "C:\!!BITBUCKET\11l-lang\_11l_to_cpp\11l.hpp"

struct CodeBlock1
{
    CodeBlock1()
    {
        print(create_array(range_ee(u'A'_C, u'Z'_C)));
    }
} code_block_1;

int main()
{
}
