import prime2

print(prime2.prime())