﻿class Error
{
public:
    String message;
};
