﻿template <typename T1 = decltype(0)> auto _(const T1 &a = 0)
{
    print(a);
}
