@wireflow
def testfun(paramInt:int, paramInt2:int=1):
	return paramInt+paramInt2
